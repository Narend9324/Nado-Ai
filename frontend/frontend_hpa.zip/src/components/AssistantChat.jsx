import React, { useState } from 'react';

function AssistantChat() {
  return (
    <div>
      <p>HELLO</p>
    </div>
  )
}

export default AssistantChat;
